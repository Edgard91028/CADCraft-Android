# CADCraft Android — Revisión técnica y criterios de aceptación

## Estado verificado del paquete

- ZIP: íntegro (`zipfile.testzip()` sin errores).
- Archivos del workspace: 18 manifiestos `Cargo.toml` parseados correctamente con TOML; cero errores de sintaxis.
- Incluye `Cargo.lock`, el crate `apps/cadcraft-android`, el punto de entrada Android y el workflow de GitHub Actions.
- No se ejecutó `cargo check`, compilación Android ni prueba en dispositivo: este entorno no dispone de Rust/Cargo, Android SDK/NDK ni `adb`.

## Estado funcional conocido

| Área | Estado | Aceptación necesaria |
|---|---|---|
| Motor CAD compartido | Reutilizado en el código fuente | Compilar para `aarch64-linux-android` y probar comandos |
| Inicio Android / eframe | Implementación experimental | APK arranca y no se cierra al pausar/reanudar |
| Interfaz táctil | Sin pasada específica para móvil | Probar tap, arrastre, zoom con dos dedos y selección |
| Abrir/guardar archivos | Pendiente: el crate Android crea `Services::default()` sin selectores | Integrar Storage Access Framework (ACTION_OPEN_DOCUMENT / ACTION_CREATE_DOCUMENT) y comprobar permisos/URI |
| DXF/DWG/SVG/PDF/PNG | El motor de IO registra hooks; los flujos de archivos dependen del selector y de las capacidades de cada formato | Pruebas de ida y vuelta por formato; documentar formatos no soportados |
| Portapapeles | No validado en Android | Probar copiar/pegar y adaptar servicio si procede |
| Autosalvado / persistencia | Parcial: preferencias e interfaz se guardan con eframe; rutas de autosalvado requieren validación Android | Probar reinicio, cierre forzado y recuperación |
| Rendimiento / memoria | No medido | Dibujos pequeños, medianos y grandes en dispositivo real |
| APK | Workflow experimental presente | CI verde, artefacto firmado y prueba de instalación |
| Google Play AAB | No implementado ni validado | AAB firmado, target API vigente, políticas y pruebas de publicación |

## Bloqueadores prioritarios

1. Ejecutar el workflow en un repositorio GitHub controlado por el usuario y reparar errores reales del compilador/linker.
2. Implementar los selectores de documentos Android e integrar sus URI con la capa de lectura/escritura. No tratar las URI `content://` como rutas POSIX.
3. Validar que la UI no exponga acciones de escritorio no operables en móvil; adaptar barras, menús y gestos sin quitar herramientas del motor.
4. Automatizar pruebas del motor y pruebas de importación/exportación; hacer smoke tests en Android ARM64.
5. Generar AAB y completar el proceso de firma/publicación solo después de aprobar la matriz de pruebas.

## Criterio para llamar a una versión «funcional»

No etiquetar como versión funcional hasta que la compilación CI termine correctamente, la APK se instale y arranque en un teléfono ARM64, el usuario pueda crear/editar/guardar/volver a abrir un plano mediante el selector Android, y las funciones anunciadas tengan pruebas aprobadas. La disponibilidad de herramientas en la interfaz no prueba por sí sola que sus flujos funcionen en Android.
