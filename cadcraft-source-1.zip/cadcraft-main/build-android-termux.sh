#!/data/data/com.termux/files/usr/bin/bash
# Experimental build helper. A complete Android SDK/NDK setup is required.
set -Eeuo pipefail

if ! command -v cargo >/dev/null 2>&1; then
  echo 'ERROR: Rust/Cargo not found. Install Rust in Termux first.' >&2
  exit 2
fi
if ! command -v cargo-apk >/dev/null 2>&1; then
  echo 'ERROR: cargo-apk not found. Install it with: cargo install cargo-apk --locked' >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-}" ]]; then
  echo 'ERROR: ANDROID_HOME is not set to an installed Android SDK.' >&2
  exit 2
fi
if [[ -z "${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}" ]]; then
  echo 'ERROR: ANDROID_NDK_HOME or ANDROID_NDK_ROOT is not set to an installed NDK.' >&2
  exit 2
fi

rustup target add aarch64-linux-android
cargo apk build --package cadcraft-android --release --target aarch64-linux-android

APK="$(find target -type f -name '*.apk' -print -quit)"
if [[ -z "$APK" ]]; then
  echo 'ERROR: Build command finished but no APK was found under target/.' >&2
  exit 1
fi
printf '\nAPK generated at: %s\n' "$APK"
